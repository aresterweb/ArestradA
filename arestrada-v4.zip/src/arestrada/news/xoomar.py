import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from urllib.parse import urlencode


@dataclass(frozen=True)
class NewsSnapshot:
    status: str
    reason: str
    events: tuple
    fetched_at: str
    next_release_at: str = ""


class XoomarProvider:
    BASE_URL = "https://xoomar.com/api/markets/calendar"

    def __init__(self, api_key="", timeout=12, cache_seconds=45):
        self.api_key = api_key
        self.timeout = timeout
        self.cache_seconds = max(0, cache_seconds)
        self._cache = None
        self._etag = ""

    def _request(self):
        params = urlencode({"importance": "high"})
        req = urllib.request.Request(
            f"{self.BASE_URL}?{params}",
            headers={"User-Agent": "ArestradA/4.0"},
        )

        if self.api_key:
            req.add_header("X-API-Key", self.api_key)

        if self._etag:
            req.add_header("If-None-Match", self._etag)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                body = response.read()
                etag = response.headers.get("ETag", "")
                return response.status, body, etag

        except urllib.error.HTTPError as exc:
            if exc.code == 304:
                return 304, b"", self._etag
            raise

    def snapshot(self, now=None):
        now = now or datetime.now(timezone.utc)
        timestamp = now.timestamp()

        if self._cache:
            cached_at, snapshot = self._cache
            if timestamp - cached_at < self.cache_seconds:
                return snapshot

        try:
            status, body, etag = self._request()

            if status == 304 and self._cache:
                snapshot = self._cache[1]
                self._cache = (timestamp, snapshot)
                return snapshot

            payload = json.loads(body.decode("utf-8"))
            events = payload.get("data")

            if not isinstance(events, list):
                raise RuntimeError("XOOMAR response missing data")

            if etag:
                self._etag = etag

            parsed = []

            for event in events:
                if not isinstance(event, dict):
                    continue

                scheduled = event.get("scheduledAt")
                if not scheduled:
                    continue

                try:
                    dt = datetime.fromisoformat(
                        scheduled.replace("Z", "+00:00")
                    ).astimezone(timezone.utc)
                except ValueError:
                    continue

                parsed.append(
                    {
                        "event_name": str(event.get("eventName") or ""),
                        "importance": str(event.get("importance") or "").lower(),
                        "scheduled_at": dt.isoformat(),
                        "period_label": event.get("periodLabel"),
                        "previous": event.get("previous"),
                        "actual": event.get("actual"),
                        "forecast": event.get("forecast"),
                        "unit": event.get("unit"),
                        "source": event.get("source"),
                    }
                )

            window = timedelta(minutes=30)

            blocking = [
                event
                for event in parsed
                if event["importance"] == "high"
                and abs(
                    (
                        datetime.fromisoformat(event["scheduled_at"])
                        - now
                    ).total_seconds()
                ) <= window.total_seconds()
            ]

            next_release = payload.get("nextReleaseAt") or ""

            if blocking:
                news_status = "BLOCKED"
                reason = "HIGH_IMPACT_NEWS_WINDOW"
            else:
                news_status = "CLEAR"
                reason = "XOOMAR_CALENDAR_OK"

            snapshot = NewsSnapshot(
                news_status,
                reason,
                tuple(parsed),
                now.isoformat(),
                str(next_release),
            )

            self._cache = (timestamp, snapshot)
            return snapshot

        except Exception as exc:
            snapshot = NewsSnapshot(
                "UNKNOWN",
                f"XOOMAR_ERROR:{type(exc).__name__}",
                tuple(),
                now.isoformat(),
                "",
            )
            self._cache = (timestamp, snapshot)
            return snapshot
