import os, sys
ROOT=os.path.dirname(os.path.abspath(__file__))
SRC=os.path.join(ROOT,'src')
if SRC not in sys.path: sys.path.insert(0,SRC)
os.chdir(ROOT)
from arestrada.telegram.webhook import application
