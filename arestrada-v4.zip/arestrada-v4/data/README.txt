Runtime SQLite database is created automatically as data/arestrada_v4.db. Do not upload production secrets into this directory.
