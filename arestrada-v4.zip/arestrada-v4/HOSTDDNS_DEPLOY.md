# HostDDNS Passenger deployment
Python: 3.11.9
Root: arestrada-v4
URL: aresterbot.mikhmon.app / arestrada
Startup: passenger_wsgi.py
Entry point: application
Log: /home/aresterapp/arestrada-v4/passenger.log

Keep the existing ars-mikrotik-bot application untouched.
Upload this project's CONTENTS into /home/aresterapp/arestrada-v4.
Configure secrets with the Python App Environment Variables UI, not in public files.
Required: TELEGRAM_BOT_TOKEN, TELEGRAM_OWNER_ID, TWELVEDATA_API_KEY, TELEGRAM_WEBHOOK_SECRET, TELEGRAM_WEBHOOK_URL.
Keep PAYMENT_ENABLED=false until webhook, market feed and Telegram tests pass.
