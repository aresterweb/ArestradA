import json, os, urllib.parse, urllib.request
TOKEN=os.environ.get('TELEGRAM_BOT_TOKEN',''); URL=os.environ.get('TELEGRAM_WEBHOOK_URL',''); SECRET=os.environ.get('TELEGRAM_WEBHOOK_SECRET','')
if not TOKEN or not URL or not SECRET: raise SystemExit('Missing TELEGRAM_BOT_TOKEN / TELEGRAM_WEBHOOK_URL / TELEGRAM_WEBHOOK_SECRET')
data=urllib.parse.urlencode({'url':URL,'secret_token':SECRET,'allowed_updates':json.dumps(['message','pre_checkout_query','callback_query']),'drop_pending_updates':'false'}).encode()
with urllib.request.urlopen(urllib.request.Request(f'https://api.telegram.org/bot{TOKEN}/setWebhook',data=data),timeout=20) as r: print(r.read().decode())
