def menu(plan="FREE", is_owner=False):
    rows = [
        [{"text":"⚡ Market Pulse","callback_data":"pulse"}],
        [{"text":"🔮 Next M15","callback_data":"next"},{"text":"📈 Analysis","callback_data":"analysis"}],
        [{"text":"📊 Stats","callback_data":"stats"},{"text":"👤 Account","callback_data":"account"}],
        [{"text":"🟢 Data Status","callback_data":"data status"},{"text":"📰 News Safety","callback_data":"news safety"}],
        [{"text":"⏱ Candle Timer","callback_data":"candle timer"},{"text":"ℹ Help","callback_data":"help"}],
    ]
    if is_owner: rows.append([{"text":"🛡 Owner Panel","callback_data":"owner"}])
    elif plan not in ("ELITE", "SPECIAL", "INTERNAL"): rows.append([{"text":"⭐ Upgrade","callback_data":"upgrade"}])
    return {"inline_keyboard": rows}

def dashboard(plan="FREE", is_owner=False):
    return (f"""ARESTRADA
Market Intelligence
━━━━━━━━━━━━━━━━━━
XAU/USD
● Safety-first analysis

Plan • {plan}""", menu(plan, is_owner))

def pulse(a):
    mtf="\n".join(f"{k.upper():5} {v}" for k,v in a.get("mtf",{}).items())
    return f"""ARESTRADA • MARKET PULSE
━━━━━━━━━━━━━━━━━━
XAU/USD

BIAS • {a['bias']}
Context • {a['context']}
{mtf}

Setup • {a['setup'].decision}
Quality • {a['setup'].score}/100
Data • {a['quality']} ({a['quality_reason']})
News • {a['news']}

Analysis only"""

def analysis(a):
    s=a['setup'];rs='\n'.join('• '+x for x in s.reasons) or '• No qualified evidence';ct='\n'.join('− '+x for x in s.counter) or '• None';risk=a.get('risk')
    rp='No trade plan' if not risk else f"Entry {risk['entry']:.2f}\nSL {risk['sl']:.2f}\nTP1 {risk['tp1']:.2f} • 1.5R\nTP2 {risk['tp2']:.2f} • 2.0R"
    return f"""ARESTRADA • FULL ANALYSIS
━━━━━━━━━━━━━━━━━━
Bias {a['bias']} • {a['context']}
BOS {a['structure'].bos or '-'} • CHOCH {a['structure'].choch or '-'}
Liquidity {a['liquidity'].get('event') or 'NONE'}

DECISION • {s.decision}
Grade {s.grade} • Confluence {s.score}/100

Evidence
{rs}

Counter Evidence
{ct}

RISK PLAN
{rp}

Data {a['quality']} • News {a['news']}
Analysis only"""

def next_m15(pred,target_time,quality,quality_reason):
    direction=getattr(pred.direction,"value",str(pred.direction));icon={"UP":"⬆️","DOWN":"⬇️","NEUTRAL":"↔️","NO_PREDICTION":"⛔"}.get(direction,"•");score=int(getattr(pred,"confluence",0));reason=getattr(pred,"reason","UNKNOWN")
    return f"""ARESTRADA • NEXT M15
━━━━━━━━━━━━━━━━━━
XAU/USD

Target • {target_time}
Direction • {icon} {direction}
Confluence • {score}/100
Reason • {reason}

Data • {quality} ({quality_reason})

Confluence is not probability.
Next-candle direction is not an automatic BUY/SELL signal.
Analysis only"""

def stats_view(s):return f"ARESTRADA • STATS\n━━━━━━━━━━━━━━━━━━\nUsers • {s.get('users',0)}\nPaid • {s.get('paid',0)}\nSpecial • {s.get('special',0)}\nStars received • {s.get('stars',0)}"
def account(u):return f"MY ACCOUNT\n━━━━━━━━━━━━━━━━━━\nUser {u['telegram_user_id']}\nPlan • {u['plan']}\nAccess • {u['access_source']}\nRole • {u.get('role','USER')}\nExpires • {u.get('expires_at') or '—'}"
def upgrade(pro,elite):return (f"UPGRADE ARESTRADA\n━━━━━━━━━━━━━━━━━━\nPRO • ⭐ {pro} / 30 days\nELITE • ⭐ {elite} / 30 days\n\nSubscriptions renew every 30 days until cancelled.",{"inline_keyboard":[[{"text":f"⭐ PRO • {pro}","callback_data":"buy:PRO"}],[{"text":f"⭐ ELITE • {elite}","callback_data":"buy:ELITE"}]]})

def owner_panel(stats):
    text=f"""ARESTRADA • OWNER PANEL
━━━━━━━━━━━━━━━━━━
Users • {stats.get('users',0)}
Paid • {stats.get('paid',0)}
Special • {stats.get('special',0)}
Stars • {stats.get('stars',0)}

Owner access • INTERNAL"""
    kb={"inline_keyboard":[
        [{"text":"👥 Users","callback_data":"owner:users"},{"text":"🎁 Special","callback_data":"owner:special"}],
        [{"text":"🛡 Staff","callback_data":"owner:staff"},{"text":"⭐ Revenue","callback_data":"owner:revenue"}],
        [{"text":"📊 Performance","callback_data":"owner:performance"},{"text":"📈 Strategy","callback_data":"owner:strategy"}],
        [{"text":"📡 Live Analysis","callback_data":"owner:signals"},{"text":"🖥 System","callback_data":"owner:system"}],
        [{"text":"📰 News Control","callback_data":"owner:news"},{"text":"💳 Payments","callback_data":"owner:payments"}],
        [{"text":"🧾 Audit","callback_data":"owner:audit"},{"text":"🚨 Emergency","callback_data":"owner:emergency"}],
        [{"text":"⬅️ Main Menu","callback_data":"owner:back"}],]}
    return text,kb

def owner_special_help():
    return """OWNER • SPECIAL MANAGER
━━━━━━━━━━━━━━━━━━
Grant by Telegram numeric ID:
/special <id> <7d|30d|90d|1y|lifetime>

Revoke complimentary access:
/revoke <id>

The user must have started the bot first.
All changes are audit logged."""

def owner_staff_help():
    return """OWNER • STAFF MANAGER
━━━━━━━━━━━━━━━━━━
Set delegated role:
/staff <id> <ADMIN|SUPPORT|USER>

OWNER identity cannot be delegated by this command.
All changes are audit logged."""

def owner_news_controls(status):
    return (f"OWNER • NEWS CONTROL\n━━━━━━━━━━━━━━━━━━\nCurrent • {status}\n\nManual status expires automatically when a TTL is used. UNKNOWN remains fail-closed.",{"inline_keyboard":[[{"text":"🟢 CLEAR 60m","callback_data":"owner:news:CLEAR:60"},{"text":"🟡 CAUTION 60m","callback_data":"owner:news:CAUTION:60"}],[{"text":"🔴 BLOCK 60m","callback_data":"owner:news:BLOCKED:60"},{"text":"⚪ UNKNOWN","callback_data":"owner:news:UNKNOWN:0"}],[{"text":"⬅️ Owner","callback_data":"owner"}]]})


def owner_emergency_controls(payments_on, alerts_on):
    ptxt='PAUSE payments' if payments_on else 'RESUME payments'
    atxt='PAUSE alerts' if alerts_on else 'RESUME alerts'
    return (f"OWNER • EMERGENCY CONTROL\n━━━━━━━━━━━━━━━━━━\nPayments runtime • {'ON' if payments_on else 'OFF'}\nAuto alerts runtime • {'ON' if alerts_on else 'OFF'}\n\nData Guard and news fail-closed cannot be disabled here.",{"inline_keyboard":[[{"text":"💳 "+ptxt,"callback_data":"owner:toggle:payments"}],[{"text":"🔔 "+atxt,"callback_data":"owner:toggle:alerts"}],[{"text":"🔴 Block News 60m","callback_data":"owner:news:BLOCKED:60"}],[{"text":"⬅️ Owner","callback_data":"owner"}]]})
