# ArestradA V4 — Clean Final Deployment

Clean rebuild from the supplied V4 source plus the tested finalization changes.

Validated locally:
- Python source compile: PASS
- pytest: 10 passed
- Owner identity display fix included
- Owner Panel routing included
- Next M15 routing included
- News/Data/Timer/Help routing included
- Payments remain disabled by default
- Auto alerts remain disabled by default
- No production `.env` or secrets included
- Runtime SQLite DB is intentionally NOT included; it is created on first start

HostDDNS:
1. Back up the existing `arestrada-v4` directory if it contains data you need.
2. Replace the old project contents while keeping existing Python App settings/environment variables.
3. Upload this package and extract its contents into application root `arestrada-v4`.
4. Do NOT modify `ars-mikrotik-bot`.
5. Run `tools/verify_install.py` from the Python App script runner if available.
6. Restart only ArestradA.
7. Test `/start`, Owner Panel, M15 Analysis, Next M15, Data Status, News Safety.
8. Keep `PAYMENT_ENABLED=false` and `AUTO_ALERT_ENABLED=false` until their separate production tests are completed.

IMPORTANT:
- Keep existing environment variables/secrets in the HostDDNS Python App UI.
- Do not copy a production `.env` into the package.
- If verification fails, stop before enabling payments/alerts.
