import compileall, pathlib, sys
root=pathlib.Path(__file__).resolve().parents[1]
ok=compileall.compile_dir(str(root/"src"), quiet=1, force=True)
print("SOURCE COMPILE:", "PASS" if ok else "FAIL")
try:
    sys.path.insert(0,str(root/"src"))
    from arestrada.core.config import Settings
    from arestrada.persistence.db import DB
    DB(Settings().db_path)
    print("DB INIT: PASS")
except Exception as e:
    print("DB INIT: FAIL", type(e).__name__)
    raise
