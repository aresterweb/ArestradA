from pathlib import Path
import py_compile

root = Path(__file__).resolve().parents[1]
target = root / 'src' / 'arestrada' / 'telegram' / 'webhook.py'
print('TARGET:', target)
py_compile.compile(str(target), doraise=True)
print('WEBHOOK COMPILE: PASS')
