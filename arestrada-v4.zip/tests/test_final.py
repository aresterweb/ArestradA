from datetime import datetime,timezone,timedelta
from arestrada.market.candles import Candle
from arestrada.market.quality import assess
from arestrada.core.enums import DataQuality
from arestrada.intelligence.structure import analyze
from arestrada.billing.stars import invoice,parse_payload
from arestrada.persistence.db import DB

def c(i,o=100,cl=101):return Candle(datetime(2026,1,1,tzinfo=timezone.utc)+timedelta(minutes=15*i),o,max(o,cl)+1,min(o,cl)-1,cl,1)
def test_duplicate_rejected():assert assess([c(i) for i in range(20)]+[c(19)],datetime(2026,1,1,6,tzinfo=timezone.utc),timedelta(hours=2)).state==DataQuality.INVALID
def test_wick_is_not_bos():
 cs=[c(i,100+i*.1,100+i*.1+.05) for i in range(60)];s=analyze(cs);assert s.bos in (None,'BULLISH','BEARISH')
def test_star_invoice_monthly():
 x=invoice('PRO');assert x['currency']=='XTR' and x['subscription_period']==2592000 and parse_payload(x['payload'])=='PRO'
def test_payment_idempotent(tmp_path):
 d=DB(str(tmp_path/'x.db'));d.upsert_user(123,'u');assert d.save_payment('charge1',123,'PRO',250);assert not d.save_payment('charge1',123,'PRO',250);assert d.user(123)['plan']=='PRO'
def test_owner_grant(tmp_path):
 d=DB(str(tmp_path/'x.db'));d.upsert_user(1);d.set_access(1,'SPECIAL','OWNER_GRANT',None,99);assert d.user(1)['plan']=='SPECIAL'

def test_payment_creates_active_subscription(tmp_path):
 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 assert d.save_payment('charge1',123,'PRO',250)
 p=d.payment_for_user(123,'charge1')
 s=d.active_subscription(123)
 assert p['status']=='PAID'
 assert p['plan']=='PRO'
 assert s is not None
 assert s['status']=='ACTIVE'
 assert s['charge_id']=='charge1'
 assert d.user(123)['plan']=='PRO'


def test_cancel_subscription_keeps_access_until_expiry(tmp_path):
 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 expiry=int((datetime.now(timezone.utc)+timedelta(days=20)).timestamp())
 assert d.save_payment('charge1',123,'PRO',250,expiry)
 assert d.cancel_subscription(123,'charge1',123)
 s=d.active_subscription(123)
 assert s is None
 u=d.user(123)
 assert u['plan']=='PRO'
 assert u['expires_at'] is not None

 with d.con() as c:
  row=c.execute("SELECT status,auto_renew FROM subscriptions WHERE charge_id='charge1'").fetchone()
  assert row['status']=='CANCELED'
  assert row['auto_renew']==0


def test_cancel_subscription_is_idempotent(tmp_path):
 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 assert d.save_payment('charge1',123,'PRO',250)
 assert d.cancel_subscription(123,'charge1',123)
 assert not d.cancel_subscription(123,'charge1',123)


def test_refund_payment_reverts_user_when_no_other_active_subscription(tmp_path):
 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 assert d.save_payment('charge1',123,'PRO',250)
 assert d.refund_payment('charge1',999)

 p=d.payment_for_user(123,'charge1')
 u=d.user(123)
 assert p['status']=='REFUNDED'
 assert u['plan']=='FREE'
 assert u['access_source']=='DEFAULT'
 assert u['expires_at'] is None

 with d.con() as c:
  row=c.execute("SELECT status,auto_renew FROM subscriptions WHERE charge_id='charge1'").fetchone()
  assert row['status']=='REFUNDED'
  assert row['auto_renew']==0


def test_refund_payment_is_idempotent(tmp_path):
 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 assert d.save_payment('charge1',123,'PRO',250)
 assert d.refund_payment('charge1',999)
 assert not d.refund_payment('charge1',999)


def test_refund_canceled_subscription_stops_access(tmp_path):
 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 assert d.save_payment('charge1',123,'PRO',250)
 assert d.cancel_subscription(123,'charge1',123)
 assert d.refund_payment('charge1',999)
 u=d.user(123)
 assert u['plan']=='FREE'
 assert u['expires_at'] is None


def test_refund_one_of_multiple_subscriptions_preserves_other_access(tmp_path):
 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 expiry1=int((datetime.now(timezone.utc)+timedelta(days=10)).timestamp())
 expiry2=int((datetime.now(timezone.utc)+timedelta(days=20)).timestamp())
 assert d.save_payment('charge1',123,'PRO',250,expiry1)
 assert d.save_payment('charge2',123,'ELITE',500,expiry2)

 assert d.refund_payment('charge2',999)

 u=d.user(123)
 assert u['plan']=='PRO'
 assert u['expires_at'] is not None

 with d.con() as c:
  rows=c.execute(
   "SELECT charge_id,status FROM subscriptions WHERE user_id=(SELECT id FROM users WHERE telegram_user_id=123) ORDER BY id"
  ).fetchall()
  assert [(r['charge_id'],r['status']) for r in rows]==[
   ('charge1','ACTIVE'),
   ('charge2','REFUNDED')
  ]

def test_refund_telegram_failure_does_not_change_db(tmp_path,monkeypatch):
 from arestrada.telegram import webhook

 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 assert d.save_payment('charge1',123,'PRO',250)

 monkeypatch.setattr(webhook,'DBX',d)
 from dataclasses import replace
 monkeypatch.setattr(webhook,'S',replace(webhook.S,owner_id=999))

 class FakeBot:
  def refund_star_payment(self,user_id,charge_id):
   return {'ok':False}

 monkeypatch.setattr(webhook,'BOT',FakeBot())

 result=webhook.handle(999,'/refund 123 charge1',{'from':{'id':999}})
 assert 'Telegram refund failed' in result

 assert d.payment_for_user(123,'charge1')['status']=='PAID'
 assert d.active_subscription(123)['status']=='ACTIVE'
 assert d.user(123)['plan']=='PRO'


def test_refund_telegram_exception_does_not_change_db(tmp_path,monkeypatch):
 from arestrada.telegram import webhook

 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 assert d.save_payment('charge1',123,'PRO',250)

 monkeypatch.setattr(webhook,'DBX',d)
 from dataclasses import replace
 monkeypatch.setattr(webhook,'S',replace(webhook.S,owner_id=999))

 class FakeBot:
  def refund_star_payment(self,user_id,charge_id):
   raise RuntimeError('telegram unavailable')

 monkeypatch.setattr(webhook,'BOT',FakeBot())

 result=webhook.handle(999,'/refund 123 charge1',{'from':{'id':999}})
 assert 'Refund failed' in result

 assert d.payment_for_user(123,'charge1')['status']=='PAID'
 assert d.active_subscription(123)['status']=='ACTIVE'


def test_cancel_telegram_failure_does_not_change_db(tmp_path,monkeypatch):
 from arestrada.telegram import webhook

 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 assert d.save_payment('charge1',123,'PRO',250)

 monkeypatch.setattr(webhook,'DBX',d)

 class FakeBot:
  def cancel_star_subscription(self,user_id,charge_id):
   return {'ok':False}

 monkeypatch.setattr(webhook,'BOT',FakeBot())

 result=webhook.handle(123,'/cancel',{'from':{'id':123}})
 assert 'Cancellation failed' in result

 assert d.payment_for_user(123,'charge1')['status']=='PAID'
 assert d.active_subscription(123)['status']=='ACTIVE'
 assert d.user(123)['plan']=='PRO'


def test_cancel_telegram_exception_does_not_change_db(tmp_path,monkeypatch):
 from arestrada.telegram import webhook

 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 assert d.save_payment('charge1',123,'PRO',250)

 monkeypatch.setattr(webhook,'DBX',d)

 class FakeBot:
  def cancel_star_subscription(self,user_id,charge_id):
   raise RuntimeError('telegram unavailable')

 monkeypatch.setattr(webhook,'BOT',FakeBot())

 result=webhook.handle(123,'/cancel',{'from':{'id':123}})
 assert 'Cancellation failed' in result

 assert d.payment_for_user(123,'charge1')['status']=='PAID'
 assert d.active_subscription(123)['status']=='ACTIVE'
 assert d.user(123)['plan']=='PRO'


def test_refund_requires_payment_ownership(tmp_path,monkeypatch):
 from arestrada.telegram import webhook

 d=DB(str(tmp_path/'x.db'))
 d.upsert_user(123,'u')
 d.upsert_user(456,'other')
 assert d.save_payment('charge1',123,'PRO',250)

 monkeypatch.setattr(webhook,'DBX',d)
 from dataclasses import replace
 monkeypatch.setattr(webhook,'S',replace(webhook.S,owner_id=999))

 class FakeBot:
  called=False
  def refund_star_payment(self,user_id,charge_id):
   self.called=True
   return {'ok':True}

 bot=FakeBot()
 monkeypatch.setattr(webhook,'BOT',bot)

 result=webhook.handle(999,'/refund 456 charge1',{'from':{'id':999}})
 assert 'Payment not found' in result
 assert bot.called is False
 assert d.payment_for_user(123,'charge1')['status']=='PAID'
